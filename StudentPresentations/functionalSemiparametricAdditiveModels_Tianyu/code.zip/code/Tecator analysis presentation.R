rm(list=ls())
setwd("~/Desktop/FSAM")
#==================================
source("internal gau.R")
source("Gaussian.R")
source("iterative update.R")
library(MASS)
#library(glmnet)
#library(fda)
library(caTools)
library(bisoreg)
library(mgcv)
#library(mda)
library(earth)
#library(PACE)
library(fdapace)
library(R.matlab)

#=================================
tecator <- read.table("tecator.txt", sep="")
head(tecator)

tecator <- unlist(t(tecator))

all_samples <- matrix(NA, nrow=240, ncol=125)
for (i in 1:240)
  #i = 1
all_samples[i,] <- tecator[((i-1)*125+1):(i*125)]
allPCs <- all_samples[,101:122]
allcontent <- all_samples[,123:125]
train <- all_samples[1:129,]
monit <- all_samples[130:172,]
test <- all_samples[173:215,]
E1 <- all_samples[216:223,] # extrapolation studies, Fat
E2 <- all_samples[224:240,] # extrapolation studies, Protein

set.seed(18265)
ID <- sample(x=rep(0:1, times=c(185,55)),size=240)
table(ID)
train_spec = all_samples[ID==0,1:100] # 185 100
test_spec = all_samples[ID==1,1:100] # 55 100
train_water = all_samples[ID==0,123]
test_water = all_samples[ID==1,123]
train_fat = all_samples[ID==0,124]
test_fat = all_samples[ID==1,124]
train_protein = all_samples[ID==0,125]
test_protein = all_samples[ID==1,125]

#use protein as the response
#===============================================
#FPCA using PACe
ntrain = dim(train_spec)[1]
numgrid = dim(train_spec)[2]
ntest = dim(test_spec)[1]
nm <- seq(851,1050,by=2)
train_cell <- train_spec
t_cell <- matrix(rep(nm,each=ntrain),nrow=ntrain)
#param_X <- setOptions(regular=2, selection_k = 20, rho=-1, ngrid=55)

#this cannot be run in R, we use matlab insted
# Ltrain_cell = split(train_cell,row(train_cell)) 
# Lt_cell= split(t_cell,row(t_cell)) 
# trainRes = FPCA(Ltrain_cell, Lt_cell, optns=list(maxK=20,nRegGrid=55))
#compute from Matlab, saved in trainRes.mat (including other staff like train.spec)

Res <- readMat("trainRes.mat")
train_water <- Res$train.response[,1] # 185
test_water <-  Res$test.response[,1] # 185
train_fat <- Res$train.response[,2] # 185
test_fat <-  Res$test.response[,2] # 55
train_protein <- Res$train.response[,3] # 55
test_protein <-  Res$test.response[,3] # 55
ntrain = length(train_water) # 185
ntest = length(test_water) # 55
#numgrid = dim(train_water)[2]



# plot the data
colnames(allcontent) <- c("water", "fat", "protein")
quartz()
#pdf("profiles.pdf", width=9, height=9)
#figure 3
#par(mfrow=c(2,2),pch="o", font.axis=2, font.lab=2, cex.axis=1.2, cex.lab=1.2)
matplot(x=nm, y=t(all_samples[,1:100]),lty=1,type="l",xlab="Wavelengths (nm)",ylab=" ")

quartz()
par(mfrow=c(1,3))
plot(x=allcontent[,1], y=allcontent[,2], type="p", xlab="Water", ylab="Fat")
plot(x=allcontent[,1], y=allcontent[,3], type="p", xlab="Water", ylab="Protein")
plot(x=allcontent[,2], y=allcontent[,3], type="p", xlab="Fat", ylab="Protein")





#PACE part
trainRes <- Res$trainRes
#getVal(trainRes, "no_opt")
numberBasis <- unlist(trainRes[[1]]) # 20
#trainPCscore <- getVal(trainRes, "xi_est")
trainPCscore <- matrix(unlist(trainRes[[6]]),nrow=ntrain) # 185 x 20 PC scores
# dim(trainPCscore)
# tail(trainPCscore)
# getVal(yy, "phi")
Phihat <- matrix(unlist(trainRes[[4]]), ncol=numberBasis) # 100 20
# windows()
# plot(y=Phihat[,1],x=nm, ylim=c(-0.2,0.3),type="l")
# #lines(x=nm,y=Phihat[,1])
# lines(x=nm,y=Phihat[,2])

# getVal(yy,"lambda")
lamhat <- unlist(trainRes[[3]]) # 20
#length(lamhat)
cumsum(lamhat)/sum(lamhat)

#getVal(yy,"mu") 
Mu_x = unlist(trainRes[[8]]) # mean function
quartz()
plot(nm, Mu_x, type="l")

#use FPCApred function in Matlab, the result is stored in testpace.mat
pred.test <- readMat("testpace.mat")
testPCscore <- pred.test$testPCscore
ntest <- dim(testPCscore)[1]
zeta.train <- pnorm(c(trainPCscore),sd=sqrt(rep(lamhat, each=ntrain)))
zeta.test <- pnorm(c(testPCscore),sd=sqrt(rep(lamhat, each=ntest)))
zeta.train <- matrix(zeta.train, nrow=ntrain)
zeta.test <- matrix(zeta.test, nrow=ntest)

#zeta.train[1:6,1]; zeta.test[1:6,1]
#train_protein[1:6]; test_protein[1:6]
#train_water[1:6]; test_water[1:6]
#train_fat[1:6]; test_fat[1:6]
#pairs(allcont)
#pairwise scatterplot suggests a substantial multicollinearity bewteen water and fat
#use fat as the explanatory variable in the parametric function
#in addition, it also suggests linear relationship between fat and protein


#=================================
cat("FPLS-COSSO\n")
#cosso with p = 10
lm1 <- lm(train_protein ~ train_fat)
alp0 <- c(0,as.numeric(coef(lm1)[-1]))
M0 <- seq(4.95,by=1,length.out=20)
#windows()
quartz()
tun1 <- tune.EMcosso.Gaussian(x=zeta.train[,1:10],y=train_protein,z=cbind(1,train_fat),
                              alp.ini=alp0,wt=rep(1,ncol(zeta.train)),scale=FALSE,cand.M=M0, tol=0.001, maxit=50,fold=5,plot.it=T)


fit.cosso <- EM.cosso(x=zeta.train[,1:10],y=train_protein,z=cbind(1,train_fat),alp.ini=alp0,
                      wt=rep(1,ncol(zeta.train[,1:10])), scale=FALSE, M=tun1$OptM, tol=0.001, maxit=50)

fit <- cosso.lin(x=zeta.train[,1:10],y=train_protein,z=cbind(1,train_fat), alp=fit.cosso$alp.est)
fit.sig <- predict.cosso(fit,M=tun1$OptM,type="nonzero")
fit.sig
fit.coef <- predict.cosso(fit,M=tun1$OptM,type="coefficients")
fit.pred <- predict.cosso(fit,xnew=zeta.test[,1:10], znew=cbind(1,test_fat), M=tun1$OptM,type="fit")
MSPE.cosso10 <- mean((test_protein-fit.pred)^2)
# 0.92

R2.cosso10 <- 1 - sum((fit.pred - test_protein)^2)/sum((test_protein - mean(test_protein))^2)
# 0.95



#cosso with p = 20
tun1 <- tune.EMcosso.Gaussian(x=zeta.train,y=train_protein,z=cbind(1,train_fat),
                              alp.ini=alp0,wt=rep(1,ncol(zeta.train)),scale=FALSE,cand.M=M0, tol=0.001, maxit=50,fold=5,plot.it=T)

fit.cosso <- EM.cosso(x=zeta.train,y=train_protein,z=cbind(1,train_fat),alp.ini=alp0,wt=rep(1,ncol(zeta.train)),
                      scale=FALSE, M=tun1$OptM, tol=0.001, maxit=50)
fit.cosso$tune$OptLam
#2.566212e-05

fit.cosso$alp.est
# -0.19

fit <- cosso.lin(x=zeta.train,y=train_protein,z=cbind(1,train_fat), alp=fit.cosso$alp.est)

fit.sig <- predict.cosso(fit,M=tun1$OptM,type="nonzero")
fit.sig
# 1  2  3  4  5  6  7  8 11 13 14 15 16 17 18
fit.coef <- predict.cosso(fit,M=tun1$OptM,type="coefficients")
fit.pred <- predict.cosso(fit,xnew=zeta.test, znew=cbind(1,test_fat), M=tun1$OptM,type="fit")
MSPE.cosso20.1 <- mean((test_protein-fit.pred)^2)
# 0.5208926

R2.cosso20.1 <- 1 - sum((fit.pred - test_protein)^2)/sum((test_protein - mean(test_protein))^2)
# 0.97